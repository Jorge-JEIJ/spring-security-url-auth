package com.example.demo.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/posts")
public class PostController {

    @GetMapping("/public")
    public String publicPost() {
        return "This post is PUBLIC";
    }

    @GetMapping("/{id}")
    public String getPost(@PathVariable Long id) {
        return "Viewing post " + id;
    }

    @PostMapping
    public String createPost() {
        return "Post created";
    }

    @DeleteMapping("/{id}")
    public String deletePost(@PathVariable Long id) {
        return "Post deleted " + id;
    }
}
